import sublist3r
import os

def find_all_domain(domain,domain_txt):
    subdomains = sublist3r.main(domain, 40, domain_txt, ports=None, silent=False, verbose=False,enable_bruteforce=False, engines=None)

if __name__ == "__main__":
    file_path=r"D:\Pythonprojects\pythonProject1\NIM\collect"# 获取文件路径
    domain_path=r"D:\Pythonprojects\pythonProject1\NIM\domain"
    # fileR=file_path+r'\top-1000000-domains.txt'
    fileR = file_path + r'\test.txt'
    fileW = file_path + r'\testsub.txt'
    with open(fileR,'r') as domainfile:
        for line in domainfile:
            domain=line.strip()
            domain_txt=domain_path+rf"\{domain}.txt"
            find_all_domain(domain, domain_txt)
    domainfiles=os.listdir(domain_path)

    with open(fileW,'a')as subdomainfile:
        for filename in domainfiles:
            with open(domain_path+rf"\{filename}",'r')as domain_i:
                for line in domain_i:
                    domain=line.strip()
                    subdomainfile.write(domain+'\n')

